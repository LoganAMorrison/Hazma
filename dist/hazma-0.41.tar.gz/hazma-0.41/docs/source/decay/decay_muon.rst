.. _decay_muon:

hazma.decay.muon
----------------

.. autofunction:: hazma.decay.muon
