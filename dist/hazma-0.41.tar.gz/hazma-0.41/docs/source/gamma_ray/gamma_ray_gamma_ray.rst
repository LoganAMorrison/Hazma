.. _gamma_ray_gamma_ray:

hazma.gamma_ray.gamma_ray
-------------------------

.. autofunction:: hazma.gamma_ray.gamma_ray
