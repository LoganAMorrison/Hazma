.. _phase_space:

hazma.rambo.generate_phase_space
--------------------------------

.. autofunction:: hazma.rambo.generate_phase_space
