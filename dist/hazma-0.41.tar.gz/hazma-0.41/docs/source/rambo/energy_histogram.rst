.. _energy_histogram:

hazma.rambo.generate_energy_histogram
-------------------------------------

.. autofunction:: hazma.rambo.generate_energy_histogram
