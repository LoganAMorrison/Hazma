.. _decay_short_kaon:

hazma.decay.short_kaon
----------------------

.. autofunction:: hazma.decay.short_kaon
