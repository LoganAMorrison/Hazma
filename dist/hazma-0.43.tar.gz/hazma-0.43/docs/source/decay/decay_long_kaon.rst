.. _decay_long_kaon:

hazma.decay.long_kaon
---------------------

.. autofunction:: hazma.decay.long_kaon
