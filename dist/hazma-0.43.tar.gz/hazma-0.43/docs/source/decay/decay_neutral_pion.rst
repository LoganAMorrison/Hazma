.. _decay_neutral_pion:

hazma.decay.neutral_pion
------------------------

.. autofunction:: hazma.decay.neutral_pion
