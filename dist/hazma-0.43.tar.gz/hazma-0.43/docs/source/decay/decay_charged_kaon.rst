.. _decay_charged_kaon:

hazma.decay.charged_kaon
------------------------

.. autofunction:: hazma.decay.charged_kaon
