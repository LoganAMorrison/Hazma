.. _gamma_ray_gamma_ray_rambo:

hazma.gamma_ray.gamma_ray_rambo
-------------------------------

.. autofunction:: hazma.gamma_ray.gamma_ray_rambo
