.. Hazma documentation master file, created by
   sphinx-quickstart on Sat Dec  9 12:12:04 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Hazma's documentation!
=================================

.. toctree::
    :maxdepth: 2
    :caption: Introduction and Details

    introduction.rst
    gamma_ray/gamma_ray.rst
    rambo.rst
    decay/decay.rst
    fsr.rst
    tutorial.rst





Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
