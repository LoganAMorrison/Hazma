![Logo](docs/source/_images/hazma_logo.png)
Icon made by Freepik from www.flaticon.com (Logo designed by David Reiman and Adam Coogan)

[![CircleCI](https://circleci.com/gh/LoganAMorrison/Hazma.svg?style=svg)](https://circleci.com/gh/LoganAMorrison/Hazma)

[![Build Status](https://travis-ci.org/LoganAMorrison/Hazma.svg?branch=master)](https://travis-ci.org/LoganAMorrison/Hazma)

# Hazma
Gamma ray spectrum generator for light standard model particles.

For more information, visit https://loganamorrison.github.io/Hazma/
