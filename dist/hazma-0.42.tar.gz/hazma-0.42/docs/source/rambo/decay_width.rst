.. _decay_width:

hazma.rambo.compute_decay_width
-------------------------------

.. autofunction:: hazma.rambo.compute_decay_width
