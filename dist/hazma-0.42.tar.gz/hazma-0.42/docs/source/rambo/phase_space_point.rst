.. _phase_space_point:

hazma.rambo.generate_phase_space_point
--------------------------------------

.. autofunction:: hazma.rambo.generate_phase_space_point
