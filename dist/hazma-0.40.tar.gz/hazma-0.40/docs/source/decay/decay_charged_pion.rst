.. _decay_charged_pion:

hazma.decay.charged_pion
------------------------

.. autofunction:: hazma.decay.charged_pion
