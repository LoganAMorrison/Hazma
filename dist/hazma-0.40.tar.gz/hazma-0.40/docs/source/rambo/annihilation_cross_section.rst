.. _annihilation_cross_section:

hazma.rambo.compute_annihilation_cross_section
----------------------------------------------

.. autofunction:: hazma.rambo.compute_annihilation_cross_section
